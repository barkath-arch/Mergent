# Claude Code — Capabilities Pack

Generated: 2026-08-04 · Model: `claude-opus-4-8`

This pack documents what Claude Code can do and bundles the artifacts that make
those capabilities portable. **Important:** the model's *reasoning and coding
ability* lives in the model weights and the runtime tools — those are not files
and cannot be zipped. What you CAN carry between projects is in this pack:

1. `CAPABILITIES.md` (this file) — the catalog + how to invoke things
2. `skills/` — packaged skills (public + examples + user-installed)
3. `config/` — starter templates that steer behavior (CLAUDE.md, settings.json,
   hooks, subagent definitions)

Drop `config/`'s contents into a repo and a fresh Claude session inherits that
setup.

---

## 1. General capabilities (behavior — runtime, not files)

These come from the model + harness. Listed so you know what to expect.

| Area | What it covers |
|---|---|
| **Code** | Read, write, refactor, debug across languages (Python, JS/TS, Go, etc.); follow existing codebase conventions |
| **Search & navigation** | Fast file/content search (glob, ripgrep), read excerpts, map subsystems |
| **Shell** | Run commands, build, test, install deps, inspect processes |
| **Git** | Branch, commit, push (with retry/backoff), diff, rebase, resolve conflicts |
| **GitHub** | PRs, issues, reviews, CI status, comments — via GitHub MCP tools |
| **Web** | Web search + fetch for docs/current info |
| **Multi-agent** | Fan out subagents; deterministic workflows (parallel/pipeline) |
| **Artifacts** | Publish self-contained HTML/MD pages to claude.ai |
| **Files as deliverables** | Generate + send files (zips, reports, diagrams) to the user |

These are invoked automatically as needed; nothing to configure.

---

## 2. Skills (packaged know-how — in `skills/`)

Skills are folders (`SKILL.md` + optional scripts/references) that Claude loads
on demand for a specific kind of task. This pack includes three sets.

### Actively invocable in a Claude Code session (21)

**Documents & files**
- `docx` — Word docs: TOCs, headings, tables, tracked changes
- `xlsx` — spreadsheets: formulas, charts, cleaning messy data
- `pptx` — slide decks / presentations
- `pdf` — read, merge, split, fill forms, OCR, create

**Design & visuals**
- `dataviz` — charts, dashboards, palettes (read before any chart)
- `artifact-design` — design fundamentals for artifacts
- `artifact-diagramming` — SVG/mermaid diagrams for artifacts
- `artifact-capabilities` — live/runtime behavior for published artifacts

**Engineering workflow**
- `init` — generate a CLAUDE.md documenting a codebase
- `run` — launch/drive the app to verify a change works
- `review` — review a GitHub pull request
- `security-review` — security review of pending changes
- `simplify` — refactor changed code for reuse/clarity/efficiency
- `session-start-hook` — set up a repo for Claude Code on the web
- `skill-creator` — create, edit, optimize, eval NEW skills

**Config & customization**
- `update-config` — configure the harness (settings.json, hooks, permissions)
- `keybindings-help` — customize keyboard shortcuts
- `fewer-permission-prompts` — allowlist to reduce permission prompts
- `loop` — run a prompt/command on a recurring interval

**Reference & misc**
- `claude-api` — Anthropic/Claude API reference (models, pricing, tools, caching)
- `morning` — render a styled morning-brief artifact

### Example / reference skills (in `skills/examples/`)
`mcp-builder`, `web-artifacts-builder`, `canvas-design`, `theme-factory`,
`brand-guidelines`, `doc-coauthoring`, `frontend-design`, `learn`, `paint`,
`algorithmic-art`, `slack-gif-creator`, plus consumer examples
(`grocery-shopping`, `meal-delivery`, `event-planning`, etc.). These are
reference implementations — study them or adapt with `skill-creator`.

### Invoking a skill
In a session: type `/<skill-name>` or ask for the task it covers. To install a
skill so it's discoverable, place its folder under `~/.claude/skills/<name>/`
(user level) or `.claude/skills/<name>/` (project level).

---

## 3. Config that steers behavior (in `config/`)

Copy these into a repo to shape how Claude behaves there.

- `config/CLAUDE.md` — project memory: conventions, commands, do/don't. Claude
  reads this automatically. Generate a real one with the `init` skill.
- `config/.claude/settings.json` — permissions, env vars, hooks.
- `config/.claude/hooks/` — example SessionStart hook (runs setup/tests).
- `config/.claude/agents/` — custom subagent definitions (name, model, tools,
  system prompt). Referenced by the Agent tool.

See `config/README.md` for how each file is picked up.

---

## What is NOT in this pack (and can't be)
- Model weights / the "intelligence" itself — runtime only.
- The tool runtime (bash, git, GitHub, web) — that's the Claude Code software +
  your credentials, not content.
- Live MCP server credentials/tokens — configure those per environment.

To actually *use* the capabilities: run Claude Code (CLI, web at
claude.ai/code, desktop, IDE extension, or the Claude Agent SDK) in a repo that
contains the `config/` from this pack.
