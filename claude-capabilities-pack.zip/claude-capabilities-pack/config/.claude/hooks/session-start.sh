#!/usr/bin/env bash
# Example SessionStart hook — runs when a Claude Code session begins.
# Use it to make the repo ready: install deps, warm caches, print key commands.
# Keep it fast and idempotent. Exit non-zero to signal setup failure.
set -euo pipefail

echo "[session-start] preparing environment..."
# Examples (uncomment what applies):
# [ -f package.json ] && npm ci --silent
# [ -f requirements.txt ] && pip install -q -r requirements.txt
echo "[session-start] ready."
