# CLAUDE.md — Project Memory (template)

Claude Code reads this file automatically at the start of a session. Replace the
placeholders with your project's real details. Generate a complete one from an
existing codebase with the `init` skill.

## Project overview
<!-- One paragraph: what this project is and its stack. -->
- Stack:
- Entry points:

## Commands
```bash
# install
# run / dev
# test
# lint / typecheck
# build
```

## Conventions
- Code style:
- Branching:
- Commit messages:

## Do / Don't
- DO:
- DON'T:

## Gotchas
<!-- Non-obvious things a new contributor (or Claude) should know. -->
