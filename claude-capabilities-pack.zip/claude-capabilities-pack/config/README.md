# Config templates — how each file is loaded

Copy these into the ROOT of a repo (merge with existing `.claude/`).

| Path | Purpose | Loaded when |
|---|---|---|
| `CLAUDE.md` | Project memory (conventions, commands) | Read automatically at session start |
| `.claude/settings.json` | Permissions, env vars, hooks | Read at session start |
| `.claude/hooks/session-start.sh` | Setup script | Run by the SessionStart hook |
| `.claude/agents/*.md` | Custom subagent definitions | Available to the Agent tool by `name` |

Notes:
- `settings.json` here is a STARTER — trim permissions to your needs. Never put
  secrets in `env`; use the environment's secret mechanism.
- Make hook scripts executable (`chmod +x`).
- Subagent frontmatter: `name`, `description`, optional `model` and `tools`.
- Generate an accurate `CLAUDE.md` for a real codebase with the `init` skill.
